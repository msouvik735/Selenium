package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginStep1 {
	
	public static String browser = "chrome";
	public static WebDriver driver;
	
	@Given("browser is open")
	public void browser_is_open() {
		if (browser.equals("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		} else if (browser.equals("edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		} else if (browser.equals("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}

		driver.get("http://practice.automationtesting.in/");
		System.out.println("Browser is open");
	}
	
	@And("user is on login page")
	public void user_is_on_login_page() throws InterruptedException {
		
		driver.findElement(By.xpath("//*[@id=\"menu-item-50\"]/a")).click();
		Thread.sleep(3000);
		System.out.println("Inside step- user is on login page");
	}

	@When("user enters username and password")
	public void user_enters_username_and_password() throws InterruptedException {
		
		driver.findElement(By.id("username")).sendKeys("mneel735@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Souvik@12345");
		Thread.sleep(3000);
		System.out.println("Inside step- user enters username and password");
	}

	@Then("To observe outcomes or validation")
	public void to_observe_outcomes_or_validation() {
		System.out.println("Inside step- user observes outcome or validation");
	}

	@And("Clicks on login button")
	public void clicks_on_login_button() {
		driver.findElement(By.name("login")).click();
		System.out.println("Inside step- user clicks on login button");
	}

	@Then("User is navigated to homepage")
	public void user_is_navigated_to_homepage() {
		System.out.println("Inside step- user navigated to page");
	}
}
